(function($) {
	$('.content').richText();
})(jQuery);