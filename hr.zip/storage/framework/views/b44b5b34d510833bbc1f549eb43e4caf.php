<?php $__env->startSection('content'); ?>
    <!-- PAGE-HEADER -->
    <div class="page-header">
        <div>
            <h1 class="page-title">Dashboard</h1>
            <ol class="breadcrumb">
                <li class="breadcrumb-item"><a href="#">Home</a></li>
                <li class="breadcrumb-item active" aria-current="page">Dashboard</li>
            </ol>
        </div>
    </div>
    <!-- PAGE-HEADER END -->

    <div class="row">
        <div class="col-xl-3 col-sm-6">
            <div class="card">
                <div class="card-body">
                    <div class="row mb-1">
                        <div class="col">
                            <p class="mb-1">Total Employees</p>
                            <h3 class="mb-0 number-font"><?php echo e($totalUsers); ?></h3>
                        </div>
                        <div class="col-auto mb-0">
                            <div class="dash-icon">
                                <i class="fe fe-user text-orange"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="row">

        <?php if(auth()->user()->hasRole('admin')): ?>

            <div class="col-xl-4 col-sm-6">
                <div class="card">
                    <div class="card-body">
                        <div class="row mb-1">
                            <div class="col">
                                <p class="mb-1"> Sick Leaves</p>
                                <h3 class="mb-0 number-font"><?php echo e($userLeaveCounts['Sick Leave']); ?></h3>
                            </div>
                            <div class="col-auto mb-0">
                                <div class="dash-icon">
                                    <i class="fe fe-user text-secondary1"></i>

                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-sm-6">
                <div class="card">
                    <div class="card-body">
                        <div class="row mb-1">
                            <div class="col">
                                <p class="mb-1"> Casual Leaves</p>
                                <h3 class="mb-0 number-font"><?php echo e($userLeaveCounts['Casual Leave']); ?></h3>
                            </div>
                            <div class="col-auto mb-0">
                                <div class="dash-icon">
                                    <i class="fe fe-user text-secondary"></i>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-sm-6">
                <div class="card">
                    <div class="card-body">
                        <div class="row mb-1">
                            <div class="col">
                                <p class="mb-1"> Annual Leaves</p>
                                <h3 class="mb-0 number-font"><?php echo e($userLeaveCounts['Annual Leave']); ?></h3>
                            </div>
                            <div class="col-auto mb-0">
                                <div class="dash-icon">
                                    <i class="fe fe-user text-warning"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php else: ?>
        
        <div class="col-xl-4 col-sm-6">
            <div class="card">
                <div class="card-body">
                    <div class="row mb-1">
                        <div class="col">
                            <p class="mb-1">Sick Leave (Total)</p>
                            <h3 class="mb-0 number-font"><?php echo e($leaveData['total']['Sick Leave']); ?></h3>
                        </div>
                        <div class="col-auto mb-0">
                            <div class="dash-icon">
                                <i class="fe fe-user text-secondary1"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-4 col-sm-6">
            <div class="card">
                <div class="card-body">
                    <div class="row mb-1">
                        <div class="col">
                            <p class="mb-1">Sick Leave (Remaining)</p>
                            <h3 class="mb-0 number-font"><?php echo e($leaveData['remaining']['Sick Leave']); ?></h3>
                        </div>
                        <div class="col-auto mb-0">
                            <div class="dash-icon">
                                <i class="fe fe-user text-secondary1"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-4 col-sm-6">
            <div class="card">
                <div class="card-body">
                    <div class="row mb-1">
                        <div class="col">
                            <p class="mb-1">Sick Leave (Taken)</p>
                            <h3 class="mb-0 number-font"><?php echo e($leaveData['taken']['Sick Leave']); ?></h3>
                        </div>
                        <div class="col-auto mb-0">
                            <div class="dash-icon">
                                <i class="fe fe-user text-secondary1"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="col-xl-4 col-sm-6">
            <div class="card">
                <div class="card-body">
                    <div class="row mb-1">
                        <div class="col">
                            <p class="mb-1">Casual Leave (Total)</p>
                            <h3 class="mb-0 number-font"><?php echo e($leaveData['total']['Casual Leave']); ?></h3>
                        </div>
                        <div class="col-auto mb-0">
                            <div class="dash-icon">
                                <i class="fe fe-user text-secondary"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-4 col-sm-6">
            <div class="card">
                <div class="card-body">
                    <div class="row mb-1">
                        <div class="col">
                            <p class="mb-1">Casual Leave (Remaining)</p>
                            <h3 class="mb-0 number-font"><?php echo e($leaveData['remaining']['Casual Leave']); ?></h3>
                        </div>
                        <div class="col-auto mb-0">
                            <div class="dash-icon">
                                <i class="fe fe-user text-secondary"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-4 col-sm-6">
            <div class="card">
                <div class="card-body">
                    <div class="row mb-1">
                        <div class="col">
                            <p class="mb-1">Casual Leave (Taken)</p>
                            <h3 class="mb-0 number-font"><?php echo e($leaveData['taken']['Casual Leave']); ?></h3>
                        </div>
                        <div class="col-auto mb-0">
                            <div class="dash-icon">
                                <i class="fe fe-user text-secondary"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        
        <div class="col-xl-4 col-sm-6">
            <div class="card">
                <div class="card-body">
                    <div class="row mb-1">
                        <div class="col">
                            <p class="mb-1">Annual Leave (Total)</p>
                            <h3 class="mb-0 number-font"><?php echo e($leaveData['total']['Annual Leave']); ?></h3>
                        </div>
                        <div class="col-auto mb-0">
                            <div class="dash-icon">
                                <i class="fe fe-user text-warning"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-4 col-sm-6">
            <div class="card">
                <div class="card-body">
                    <div class="row mb-1">
                        <div class="col">
                            <p class="mb-1">Annual Leave (Remaining)</p>
                            <h3 class="mb-0 number-font"><?php echo e($leaveData['remaining']['Annual Leave']); ?></h3>
                        </div>
                        <div class="col-auto mb-0">
                            <div class="dash-icon">
                                <i class="fe fe-user text-warning"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-xl-4 col-sm-6">
            <div class="card">
                <div class="card-body">
                    <div class="row mb-1">
                        <div class="col">
                            <p class="mb-1">Annual Leave (Taken)</p>
                            <h3 class="mb-0 number-font"><?php echo e($leaveData['taken']['Annual Leave']); ?></h3>
                        </div>
                        <div class="col-auto mb-0">
                            <div class="dash-icon">
                                <i class="fe fe-user text-warning"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php endif; ?>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\hr\resources\views/home.blade.php ENDPATH**/ ?>