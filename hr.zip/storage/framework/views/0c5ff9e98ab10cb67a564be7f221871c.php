<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
<?php echo $__env->make('layouts.partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>
<body class="app sidebar-mini dark-mode">
<!-- GLOBAL-LOADER -->
<div id="global-loader">
    <img src="<?php echo e(asset('theme/assets/images/loader.svg')); ?>" class="loader-img" alt="Loader">
</div>
<!-- /GLOBAL-LOADER -->
<div class="page">
    <div class="page-main">
        <?php echo $__env->make('layouts.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('layouts.partials.top-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!--app-content open-->
            <div class="app-content">
                <div class="side-app">
                    <?php echo $__env->yieldContent('content'); ?>
                </div>

            </div>

    </div>


    <?php echo $__env->make('layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
</body>
</html>
<?php /**PATH C:\laragon\www\hr\resources\views/layouts/app.blade.php ENDPATH**/ ?>