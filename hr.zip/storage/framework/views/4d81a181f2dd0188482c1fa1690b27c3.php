<?php $__env->startPush('styles'); ?>
    <link href="<?php echo e(asset('theme/assets/plugins/datatable/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('theme/assets/plugins/sweet-alert/sweetalert.css')); ?>" rel="stylesheet" />


<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
            <!-- PAGE-HEADER -->
            <div class="page-header">
                <div>
                    <h1 class="page-title">Leave Applications</h1>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('leave_applications')); ?>">Leave Applications</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Leave Applications List</li>
                    </ol>
                </div>
                <div class="ml-auto pageheader-btn">
                    <a href="<?php echo e(route('leave_applications.create')); ?>" class="btn btn-primary btn-icon text-white mr-2">
									<span>
										<i class="fe fe-plus"></i>
									</span> Apply Leave
                    </a>

                </div>
            </div>
            <!-- PAGE-HEADER END -->
            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <p><?php echo e($message); ?></p>
                </div>
            <?php endif; ?>
            <!-- ROW-2 OPEN -->
            <div class="row">
                <div class="col-md-12 col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Leave Applications</h3>
                            <div class="ml-auto pageheader-btn">
                                <div class="col-md-12">
                                    <label for="filter-month">Filter by Month:</label>
                                    <select id="monthSelect" class="form-control">
                                        <option value="0">Select Month</option>
                                        <option value="1">January</option>
                                        <option value="2">February</option>
                                        <option value="3">March</option>
                                        <option value="4">April</option>
                                        <option value="5">May</option>
                                        <option value="6">June</option>
                                        <option value="7">July</option>
                                        <option value="8">August</option>
                                        <option value="9">September</option>
                                        <option value="10">October</option>
                                        <option value="11">November</option>
                                        <option value="12">December</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="data-table1" class="table table-striped table-bordered text-nowrap w-100">
                                    <thead>
                                    <tr>
                                        <th class="wd-15p">ID</th>
                                        <th class="wd-15p">Employee</th>
                                        <th class="wd-15p">Leave Type</th>
                                        <th class="wd-15p">Start Date</th>
                                        <th class="wd-15p">End Date</th>
                                        <th class="wd-15p">Days</th>
                                        <th class="wd-15p">Hours</th>
                                        <th class="wd-15p">Time (From-To)</th>
                                        <th class="wd-15p">Status</th>
                                        <th class="wd-25p">Actions</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $leaveApplications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($leave->id); ?></td>
                                        <td><?php echo e($leave->user->name); ?></td>
                                        <td><?php echo e($leave->leaveType->name); ?></td>
                                        <td>
                                            <?php if($leave->start_date): ?>
                                                <?php echo e(date('d-m-Y', strtotime($leave->start_date))); ?>

                                            <?php endif; ?>
                                                </td>
                                        <td>
                                            <?php if($leave->end_date): ?>
                                                <?php echo e(date('d-m-Y', strtotime($leave->end_date))); ?>

                                            <?php endif; ?>
                                               </td>
                                        <td><?php echo e($leave->number_of_days); ?></td>
                                        <td><?php echo e($leave->number_of_hours); ?></td>
                                        <td>
                                            <?php if($leave->start_time): ?>
                                                <?php echo e(date('h:i A', strtotime($leave->start_time))); ?>

                                            <?php endif; ?>
                                                <?php if($leave->end_time): ?>
                                                    <?php echo e(date('h:i A', strtotime($leave->end_time))); ?>

                                                <?php endif; ?>
                                            </td>
                                        <td>
                                            <?php if($leave->status == 0): ?>
                                                <div class="tags">
                                                    <span class="tag tag-yellow">Pending</span>
                                                </div>
                                            <?php elseif($leave->status == 1): ?>
                                                <div class="tags">
                                                    <span class="tag tag-blue">Sent for Approval</span>
                                                </div>
                                            <?php elseif($leave->status == 2): ?>
                                                <div class="tags">
                                                    <span class="tag tag-lime">Approved</span>
                                                </div>
                                            <?php elseif($leave->status == 3): ?>
                                                <div class="tags">
                                                    <span class="tag tag-red">Denied</span>
                                                </div>
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php if(auth()->user()->hasRole('teamlead') && $leave->status == 0): ?>
                                                <button class="btn btn-success" onclick="sendForApproval(<?php echo e($leave->id); ?>)">Send for Approval</button>
                                                <button class="btn btn-danger" onclick="denyLeave(<?php echo e($leave->id); ?>)">Deny</button>
                                            <?php endif; ?>

                                            <?php if(auth()->user()->hasRole('manager') && $leave->status == 1): ?>
                                                <button class="btn btn-primary" onclick="approve(<?php echo e($leave->id); ?>)">Approve</button>
                                                    <button class="btn btn-danger" onclick="denyLeave(<?php echo e($leave->id); ?>)">Deny</button>
                                            <?php endif; ?>
                                            
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('leave-application-delete')): ?>
                                                
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <!-- TABLE WRAPPER -->
                    </div>
                    <!-- SECTION WRAPPER -->
                </div>
            </div>
            <!-- ROW-2 CLOSED -->

<?php $__env->startPush('script'); ?>
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $(function(e) {
         $(document).on("click", "#confirm", function(e) {
             e.preventDefault();
             const deleteUrl = $(this).data('delete-url');
        swal({
            title: "Alert",
            text: "Are you really want to delete?",
            type: "warning",
            showCancelButton: true,
            confirmButtonText: 'Yes',
            cancelButtonText: 'No'
        }, function(result) {
            if (result) {
                $.ajax({
                    url: deleteUrl,
                    type: 'DELETE',
                    success: function(response) {
                        window.location.href = '/leave_applications';
                    },
                    error: function(error) {
                        // Handle error response
                        console.log("Error deleting leave type");
                        window.location.href = '/leave_applications';
                    }
                });

            } else {

                console.log("User decided to stay on the page");
            }
        });
    });
        });
    </script>
    <script>
            function sendForApproval(leaveId) {
                $.ajax({
                    url: `/leave_applications/${leaveId}/send-for-approval`,
                    type: 'POST',
                    success: function(response) {
                        // Disable the button after successful action
                        $(`#sendForApprovalBtn${leaveId}`).prop('disabled', true);
                        window.location.href = '/leave_applications';
                    },
                    error: function(error) {
                        // Handle errors
                        // ...
                    }
                });
            }

            function approve(leaveId) {
                $.ajax({
                    url: `/leave_applications/${leaveId}/approve`,
                    type: 'POST',
                    success: function(response) {
                        // Disable the button after successful action
                        $(`#approveBtn${leaveId}`).prop('disabled', true);
                        window.location.href = '/leave_applications';
                    },
                    error: function(error) {
                        // Handle errors
                        // ...
                    }
                });
            }
            function denyLeave(id) {
                $.ajax({
                    url: `/leave_applications/${id}/deny`,
                    type: 'POST',
                    success: function(response) {
                        console.log(response);
                        // Disable the button after successful action
                        //$(`#approveBtn${id}`).prop('disabled', true);
                        window.location.href = '/leave_applications';
                    },
                    error: function(error) {
                        // Handle errors
                        // ...
                    }
                });
            }

            $("#monthSelect").change(function () {
                var selectedMonth = document.getElementById('monthSelect').value;
                if(selectedMonth >0){
                    window.location.href = "<?php echo e(route('leave_applications.index')); ?>?month=" + selectedMonth;

                }



            });
    </script>

    <script src="<?php echo e(asset('theme/assets/plugins/datatable/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('theme/assets/plugins/datatable/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('theme/assets/plugins/datatable/datatable.js')); ?>"></script>
    <script src="<?php echo e(asset('theme/assets/plugins/datatable/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('theme/assets/plugins/sweet-alert/sweetalert.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\hr\resources\views/leave-applications/index.blade.php ENDPATH**/ ?>