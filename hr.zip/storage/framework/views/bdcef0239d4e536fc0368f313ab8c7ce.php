<?php $__env->startPush('styles'); ?>
    <link href="<?php echo e(asset('theme/assets/plugins/datatable/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet"/>
    <link href="<?php echo e(asset('theme/assets/plugins/sweet-alert/sweetalert.css')); ?>" rel="stylesheet" />


<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
            <!-- PAGE-HEADER -->
            <div class="page-header">
                <div>
                    <h1 class="page-title">Leave Type</h1>
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(url('leave-types')); ?>">Leave Type</a></li>
                        <li class="breadcrumb-item active" aria-current="page">Leave Type List</li>
                    </ol>
                </div>
                <div class="ml-auto pageheader-btn">
                    <a href="<?php echo e(route('leave-types.create')); ?>" class="btn btn-primary btn-icon text-white mr-2">
									<span>
										<i class="fe fe-plus"></i>
									</span> Create Leave Type
                    </a>

                </div>
            </div>
            <!-- PAGE-HEADER END -->
            <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <p><?php echo e($message); ?></p>
                </div>
            <?php endif; ?>
            <!-- ROW-2 OPEN -->
            <div class="row">
                <div class="col-md-12 col-lg-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Leave Types</h3>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table id="data-table1" class="table table-striped table-bordered text-nowrap w-100">
                                    <thead>
                                    <tr>
                                        <th class="wd-15p">ID</th>
                                        <th class="wd-15p">Name</th>
                                        <th class="wd-15p">Leave Count</th>
                                        <th class="wd-25p">Actions</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $leaveTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leaveType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($leaveType->id); ?></td>
                                        <td><?php echo e($leaveType->name); ?></td>
                                        <td><?php echo e($leaveType->count); ?></td>
                                        <td>
                                            <?php if($leaveType->name != 'Short Leave'): ?>
                                            <button class="btn btn-danger btn-icon text-white" id="resetLeaveBalances" data-value="<?php echo e($leaveType->id); ?>">
                                                    <span>
                                                        <i class="fe fe-refresh-cw"></i>
                                                    </span> Reset Leave Balances
                                            </button>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('leave-type-edit')): ?>
                                            <a href="<?php echo e(route('leave-types.edit',$leaveType->id)); ?>" data-toggle="tooltip" data-placement="top" title="Edit Role" class="btn btn-icon  btn-primary"><i class="fe fe-edit"></i></a>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('leave-type-delete')): ?>
                                                <a type="button" class="btn btn-icon btn-danger" data-toggle="tooltip" data-placement="top" title="Delete Record" id="confirm" data-delete-url="<?php echo e(url('leave-types/delete/'.$leaveType->id)); ?>">
                                                    <i class="fe fe-trash"></i></a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <!-- TABLE WRAPPER -->
                    </div>
                    <!-- SECTION WRAPPER -->
                </div>
            </div>
            <!-- ROW-2 CLOSED -->

<?php $__env->startPush('script'); ?>
    <script>
        $.ajaxSetup({
            headers: {
                'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
            }
        });

        $(function(e) {
         $(document).on("click", "#confirm", function(e) {
             e.preventDefault();
             const deleteUrl = $(this).data('delete-url');
        swal({
            title: "Alert",
            text: "Are you really want to delete?",
            type: "warning",
            showCancelButton: true,
            confirmButtonText: 'Yes',
            cancelButtonText: 'No'
        }, function(result) {
            if (result) {
                $.ajax({
                    url: deleteUrl,
                    type: 'DELETE',
                    success: function(response) {
                        window.location.href = '/leave-types';
                    },
                    error: function(error) {
                        // Handle error response
                        console.log("Error deleting leave type");
                        window.location.href = '/leave-types';
                    }
                });

            } else {

                console.log("User decided to stay on the page");
            }
        });
    });

            $(document).on("click", "#resetLeaveBalances", function(e) {
                e.preventDefault();
                var leaveType_id = $(this).data('value');
                //console.log(leaveType_id);return false;
                swal({
                    title: "Reset Leave Balances",
                    text: "Are you sure you want to reset leave balances for all users with this leave type?",
                    type: "warning",
                    showCancelButton: true,
                    confirmButtonText: "Yes",
                    cancelButtonText: "No",
                }, function (result) {
                    if (result) {
                        // Send an AJAX request to reset leave balances
                        $.ajax({
                            url: "<?php echo e(route('leave-types.resetLeaveBalances')); ?>",
                            type: "POST",
                            dataType: "json",
                            data: {
                                leave_type_id: leaveType_id,
                                _token: "<?php echo e(csrf_token()); ?>",
                            },
                            success: function (response) {
                                if (response.success) {
                                    swal("Success", "Leave balances reset successfully!", "success");
                                    // You can add any additional actions here, like reloading the page
                                } else {
                                    swal("Error", "Failed to reset leave balances!", "error");
                                }
                            },
                            error: function (error) {
                                swal("Error", "Failed to reset leave balances!", "error");
                            },
                        });
                    }
                });
            });




        });
    </script>

    <script src="<?php echo e(asset('theme/assets/plugins/datatable/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('theme/assets/plugins/datatable/dataTables.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('theme/assets/plugins/datatable/datatable.js')); ?>"></script>
    <script src="<?php echo e(asset('theme/assets/plugins/datatable/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('theme/assets/plugins/sweet-alert/sweetalert.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\hr\resources\views/leave-types/index.blade.php ENDPATH**/ ?>